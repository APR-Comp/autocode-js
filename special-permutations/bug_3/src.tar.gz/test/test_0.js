
var { specialPerm  } = require('../solution');
var assert = require('assert');
  describe('test_0', function () {
    it('For input nums = [2,3,6], the result should be 2', function () {
      assert.deepEqual( specialPerm( [2,3,6]) , 2);
    });
  });
    
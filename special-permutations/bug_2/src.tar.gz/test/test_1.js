
var { specialPerm  } = require('../solution');
var assert = require('assert');
  describe('test_1', function () {
    it('For input nums = [1,4,3], the result should be 2', function () {
      assert.deepEqual( specialPerm( [1,4,3]) , 2);
    });
  });
    
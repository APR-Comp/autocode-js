
var { specialPerm  } = require('../solution');
var assert = require('assert');
  describe('test_2', function () {
    it('For input nums = [2,3], the result should be 0', function () {
      assert.deepEqual( specialPerm( [2,3]) , 0);
    });
  });
    
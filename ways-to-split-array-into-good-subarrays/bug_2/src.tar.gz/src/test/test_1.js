
var { numberOfGoodSubarraySplits  } = require('../solution');
var assert = require('assert');
  describe('test_1', function () {
    it('For input nums = [0,1,0], the result should be 1', function () {
      assert.deepEqual( numberOfGoodSubarraySplits( [0,1,0]) , 1);
    });
  });
    

var { numberOfGoodSubarraySplits  } = require('../solution');
var assert = require('assert');
  describe('test_2', function () {
    it('For input nums = [0], the result should be 0', function () {
      assert.deepEqual( numberOfGoodSubarraySplits( [0]) , 0);
    });
  });
    
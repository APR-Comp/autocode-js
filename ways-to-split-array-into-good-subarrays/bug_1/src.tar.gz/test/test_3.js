
var { numberOfGoodSubarraySplits  } = require('../solution');
var assert = require('assert');
  describe('test_3', function () {
    it('For input nums = [1], the result should be 1', function () {
      assert.deepEqual( numberOfGoodSubarraySplits( [1]) , 1);
    });
  });
    
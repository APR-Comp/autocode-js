
var { minimumBeautifulSubstrings  } = require('../solution');
var assert = require('assert');
  describe('test_1', function () {
    it('For input s = "111", the result should be 3', function () {
      assert.deepEqual( minimumBeautifulSubstrings( "111") , 3);
    });
  });
    
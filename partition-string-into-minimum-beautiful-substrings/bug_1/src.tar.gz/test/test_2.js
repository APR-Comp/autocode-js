
var { minimumBeautifulSubstrings  } = require('../solution');
var assert = require('assert');
  describe('test_2', function () {
    it('For input s = "0", the result should be -1', function () {
      assert.deepEqual( minimumBeautifulSubstrings( "0") , -1);
    });
  });
    
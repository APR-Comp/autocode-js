
var { minimumBeautifulSubstrings  } = require('../solution');
var assert = require('assert');
  describe('test_0', function () {
    it('For input s = "1011", the result should be 2', function () {
      assert.deepEqual( minimumBeautifulSubstrings( "1011") , 2);
    });
  });
    

var { countDigits  } = require('../solution');
var assert = require('assert');
  describe('test_2', function () {
    it('For input num = 1248, the result should be 4', function () {
      assert.deepEqual( countDigits( 1248) , 4);
    });
  });
    
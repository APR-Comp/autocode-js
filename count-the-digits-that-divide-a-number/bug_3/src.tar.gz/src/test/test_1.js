
var { countDigits  } = require('../solution');
var assert = require('assert');
  describe('test_1', function () {
    it('For input num = 121, the result should be 2', function () {
      assert.deepEqual( countDigits( 121) , 2);
    });
  });
    
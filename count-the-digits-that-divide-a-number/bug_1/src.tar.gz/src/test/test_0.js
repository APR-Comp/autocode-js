
var { countDigits  } = require('../solution');
var assert = require('assert');
  describe('test_0', function () {
    it('For input num = 7, the result should be 1', function () {
      assert.deepEqual( countDigits( 7) , 1);
    });
  });
    
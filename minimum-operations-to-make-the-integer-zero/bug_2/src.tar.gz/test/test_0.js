
var { makeTheIntegerZero  } = require('../solution');
var assert = require('assert');
  describe('test_0', function () {
    it('For input num1 = 3, num2 = -2, the result should be 3', function () {
      assert.deepEqual( makeTheIntegerZero( 3, -2) , 3);
    });
  });
    
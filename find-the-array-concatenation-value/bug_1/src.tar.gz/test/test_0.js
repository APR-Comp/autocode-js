
var { findTheArrayConcVal  } = require('../solution');
var assert = require('assert');
  describe('test_0', function () {
    it('For input nums = [7,52,2,4], the result should be 596', function () {
      assert.deepEqual( findTheArrayConcVal( [7,52,2,4]) , 596);
    });
  });
    
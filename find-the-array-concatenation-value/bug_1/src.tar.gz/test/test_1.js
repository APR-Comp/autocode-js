
var { findTheArrayConcVal  } = require('../solution');
var assert = require('assert');
  describe('test_1', function () {
    it('For input nums = [5,14,13,8,12], the result should be 673', function () {
      assert.deepEqual( findTheArrayConcVal( [5,14,13,8,12]) , 673);
    });
  });
    